package com.mobilions.fxonline;
import java.util.Comparator;

public class ComparePos2 implements Comparator<TabRow>{

	public int compare(TabRow o1, TabRow o2) {
		if(o1.pos2>o2.pos2)
			return 1;
		else if(o1.pos2<o2.pos2)
			return -1;
		else

			
		return 0;
	}
	
}
