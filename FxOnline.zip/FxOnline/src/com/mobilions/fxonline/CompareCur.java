package com.mobilions.fxonline;


import java.util.Comparator;

public class CompareCur implements Comparator<TabRow>{

	public int compare(TabRow o1, TabRow o2) {
		if(o1.cur.compareTo(o2.cur)>0)
			return 1;
		else if(o1.cur.compareTo(o2.cur)<0)
			return -1;
		else

			
		return 0;
	}

	
	

	
}
